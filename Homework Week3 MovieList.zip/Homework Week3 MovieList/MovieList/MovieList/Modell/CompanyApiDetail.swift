//
//  ApiModelextra.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 11/04/2022.
//

//
//import Foundation
//
//struct Details: Codable {
//
//let newDetails: [CompanyDetails]
//
//}
//
//struct CompanyDetails : Codable {
//
//        let adult: Bool
//        let backdropPath: String
//        let homepage: String
//        let id: Int
//        let imdbID, originalLanguage, originalTitle, overview: String
//        let popularity: Double
//        let posterPath: String
//        let releaseDate: String
//        let revenue, runtime: Int
//        let status, tagline, title: String
//        let voteAverage: Double
//        let voteCount: Int
//    
//        enum CodingKeys: String, CodingKey {
//            
//            case adult
//            case backdropPath = "backdrop_path"
//            case homepage, id
//            case imdbID = "imdb_id"
//            case originalLanguage = "original_language"
//            case originalTitle = "original_title"
//            case overview, popularity
//            case posterPath = "poster_path"
//            case productionCompanies = "production_companies"
//            case productionCountries = "production_countries"
//            case releaseDate = "release_date"
//            case revenue, runtime
//            case status, tagline, title
//            case voteAverage = "vote_average"
//            case voteCount = "vote_count"
//   
// 
//}
//}
//
