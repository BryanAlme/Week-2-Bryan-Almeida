//
//  ApiModelBase.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 07/04/2022.
//

import Foundation

struct Welcome: Codable {
   
    let results: [Result]

}
struct Result: Codable {
   
    let backdropPath: String
    let id: Int
    let originalLanguage, originalTitle, overview: String
    let popularity: Double
    let posterPath, title: String

    enum CodingKeys: String, CodingKey {
     
        case backdropPath = "backdrop_path"
        case id
        case originalLanguage = "original_language"
        case originalTitle = "original_title"
        case overview, popularity
        case posterPath = "poster_path"
        case title
       
     
    }
}

