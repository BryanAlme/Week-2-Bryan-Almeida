//
//  CustomCellTableViewCell.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 07/04/2022.
//

import UIKit

class CustomCellTableViewCell: UITableViewCell {

static let identifier = "CustomCellTableViewCell"

private let titleLabel: UILabel = {
    let labelTitle = UILabel()
    labelTitle.translatesAutoresizingMaskIntoConstraints = false
    labelTitle.numberOfLines = 0
    labelTitle.textAlignment = .left
    labelTitle.textColor = .black
    labelTitle.text = "Title"
    return labelTitle
}()
    private let overViewPoster: UILabel = {
       let  overLabel = UILabel()
        overLabel.translatesAutoresizingMaskIntoConstraints = false
        overLabel.numberOfLines = 0
        overLabel.textAlignment = .right
        overLabel.textColor = .black
        overLabel.text = "OverView"
        return overLabel
}()

private let storyImageView: UIImageView = {
    let imageView = UIImageView()
    imageView.translatesAutoresizingMaskIntoConstraints = false
    return imageView
}()
    
    private let favButton : UIButton = {
      let favouriteButton = UIButton ()
        favouriteButton.translatesAutoresizingMaskIntoConstraints = false
        favouriteButton.setTitle("Show Details", for: .normal)
        favouriteButton.backgroundColor = .systemBlue
        favouriteButton.setTitleColor(.white, for: .normal)
        
      
        return favouriteButton
        
    }()

override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    setUpUI()
}

required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
}

private func setUpUI() {
    contentView.addSubview(titleLabel)
    contentView.addSubview(storyImageView)
    contentView.addSubview(overViewPoster)
    contentView.addSubview(favButton)
    
    let safeArea = contentView.safeAreaLayoutGuide
    
    titleLabel.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
    titleLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
    titleLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
    
    overViewPoster.topAnchor.constraint(equalTo: titleLabel.topAnchor).isActive = true
    overViewPoster.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
    overViewPoster.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
    
    storyImageView.topAnchor.constraint(equalTo:overViewPoster.bottomAnchor, constant: -20.0).isActive = true
    storyImageView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: -20.0).isActive = true
    storyImageView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: -20.0).isActive = true
    storyImageView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: -20.0).isActive = true
    
    
    favButton.topAnchor.constraint(equalTo: overViewPoster.topAnchor).isActive = true
    favButton.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
    favButton.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
    
}

    func configureCell(title: String?,overView: String?, imageData: Data?, action : UIButton) {
    titleLabel.text = title
    overViewPoster.text = overView
    storyImageView.image = nil
    if let imageData = imageData {
        storyImageView.image = UIImage(data: imageData)
    }
}

}


//protocol CustomCellDelegate : AnyObject {
//    func displayFavouriteScreen()
//
//}
//
//class CustomCellTableViewCell: UITableViewCell {
//
//    weak var delegate : CustomCellDelegate?
//    func configureCell(title : String?){
//        titlePoster?.text = title
//       overViewPoster?.text = title
//
//    }
//
//    @IBOutlet weak var titlePoster: UITextField!
//    @IBOutlet weak var posterImagen: UIImageView!
//    @IBOutlet weak var overViewPoster: UITextField!
//    @IBAction func favouriteButton(_ sender: Any) {
//        delegate?.displayFavouriteScreen()
//    }
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//
//    }
//
//
//
//}
