//
//  MainScreenTableViewViewController.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 10/04/2022.
//
 
// todo storyboard pagina Principal

import UIKit


class MainScreenTableViewViewController: UIViewController {
    
  
    
    
    @IBOutlet weak var customCell: CustomCellTableViewCell!
    @IBOutlet weak var titlePoster: UITextField!
    @IBOutlet weak var overViewField: UITextField!
    @IBOutlet weak var imagenPoster: UIImageView!
    
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var movieSearch: UISearchBar!
    @IBOutlet weak var nameUser: UILabel!
    
    
    
    @IBAction func selectorMovFav(_ sender: Any) {
        
    }
    @IBAction func configNameButton(_ sender: Any) {
        
        
    }
    @IBAction func showDetailsNextPage(_ sender: Any) {
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(didGetNotification ), name: NSNotification.Name("text"), object: nil)
        
    }
    
    @objc func didGetNotification(_ notification : Notification ){
    let text = notification.object as! String?
        nameUser.text = text}
    
    


}
