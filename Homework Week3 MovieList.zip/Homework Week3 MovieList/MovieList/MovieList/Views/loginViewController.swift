//
//  loginViewController.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 07/04/2022.
//

import UIKit

class loginViewController: UIViewController {
   
    @IBOutlet private weak var writeNameTextField:UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

}
  
    
    @IBAction func saveButton(_ sender: Any) {
        guard let username = writeNameTextField.text, !username.isEmpty
        else {
            displayErrorAlert(message: "UserName are empty")
            return}
        if username == "bryan"
        {performSegue(withIdentifier: "secondScreen", sender: nil)
            
        }
        else {
            displayErrorAlert (message: "Username Incorrect")
                
            }
    
}

    private func displayErrorAlert (message: String){
        let alert = UIAlertController(title: "ERROR", message: message, preferredStyle: .alert)
        let buttonSave = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(buttonSave)
        present(alert, animated: true, completion: nil)
        
        
    }
    

    }
