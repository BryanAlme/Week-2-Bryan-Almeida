//
//  ViewController.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 06/04/2022.


import UIKit
import Combine

class ViewController: UIViewController {
    
    @IBOutlet weak var labelName: UILabel!
    private var viewModel : ViewControllerViewModelProtocol?
    private var subcriber = Set<AnyCancellable>()
    var row : Int = 0
    
    private var userLabel: UILabel = {
        let lable = UILabel()
        lable.translatesAutoresizingMaskIntoConstraints = false
        lable.text = " "
        lable.textColor = .black
        lable.font = UIFont(name: lable.font.familyName, size: 20)
        lable.font = UIFont.boldSystemFont(ofSize: 20)
        return lable
    }()
    
    private var editUserButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(systemName: "⚙️"), for: .normal)
        button.setTitleColor(.blue, for: .normal)
        return button
    }()
    
    private var segmentContol: UISegmentedControl = {
        let segmentMoFa = UISegmentedControl()
        segmentMoFa.backgroundColor = .green
        segmentMoFa.translatesAutoresizingMaskIntoConstraints = false
        segmentMoFa.insertSegment(withTitle: "Movie List", at: 0, animated: true)
        segmentMoFa.insertSegment(withTitle: "Favorites", at: 1, animated: true)
        return segmentMoFa
    }()
        private var searchBar: UISearchBar = {
        let searchMovies = UISearchBar()
        searchMovies.translatesAutoresizingMaskIntoConstraints = false
        return searchMovies
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(CustomCellTableViewCell.self, forCellReuseIdentifier: CustomCellTableViewCell.identifier)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = .black
        setUp()
        assemblingMVVM()
        setUpBinding()
        
    }
    

    private func setUp(){
        
        view.addSubview(userLabel)
        view.addSubview(editUserButton)
        view.addSubview(segmentContol)
        view.addSubview(searchBar)
        view.addSubview(tableView)
        
        let safeArea = view.safeAreaLayoutGuide
        userLabel.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        userLabel.leftAnchor.constraint(equalTo: safeArea.leftAnchor, constant: 20).isActive = true
        userLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        editUserButton.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        editUserButton.rightAnchor.constraint(equalTo: safeArea.rightAnchor, constant: -20).isActive = true
        editUserButton.heightAnchor.constraint(equalToConstant: 35).isActive = true
        
        segmentContol.topAnchor.constraint(equalTo: userLabel.bottomAnchor).isActive = true
        segmentContol.leftAnchor.constraint(equalTo: safeArea.leftAnchor).isActive = true
        segmentContol.rightAnchor.constraint(equalTo: safeArea.rightAnchor).isActive = true
        
        searchBar.topAnchor.constraint(equalTo: segmentContol.bottomAnchor, constant: 10).isActive = true
        searchBar.leftAnchor.constraint(equalTo: safeArea.leftAnchor).isActive = true
        searchBar.widthAnchor.constraint(equalToConstant: view.frame.width - 20).isActive = true
        
        tableView.topAnchor.constraint(equalTo: searchBar.bottomAnchor).isActive = true
        tableView.leftAnchor.constraint(equalTo: safeArea.leftAnchor).isActive = true
        tableView.rightAnchor.constraint(equalTo: safeArea.rightAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        tableView.rowHeight = 80
        

        
    }
    
    private func assemblingMVVM() {
        // create mvvm
        let mainNetworkManager = MainNetworkManager()
        self.viewModel = ViewControllerViewModel(networkManager: mainNetworkManager) as! ViewControllerViewModelProtocol
    }


private func setUpBinding() {

    viewModel?
        .publisherStories
        .dropFirst()
        .receive(on: RunLoop.main)
        .sink(receiveValue: { [weak self] _ in
            self?.tableView.reloadData()
            self?.tableView.reloadData()
        })
        .store(in: &subcriber)
    
    

    viewModel?
        .publisherCache
        .dropFirst()
        .receive(on: RunLoop.main)
        .sink(receiveValue: { [weak self] _ in
            self?.tableView.reloadData()
        })
        .store(in: &subcriber)

    viewModel?.getStories()

}



}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:CustomCellTableViewCell.identifier, for: indexPath) as!
        CustomCellTableViewCell
        return cell
    }
    
    
}

    extension ViewController: UITableViewDelegate{
        func tableView(_ tableView: UITableView, didSelectRowAt:IndexPath){
            tableView.deselectRow(at: didSelectRowAt, animated: true)
            print("Hello \(didSelectRowAt.row)")
            self.row = didSelectRowAt.row
            self.performSegue(withIdentifier: "secondScreen", sender: self)
        }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let details = segue.destination as!DetailMovieViewController
            let title: String? = viewModel?.getTitle(by: row)
            let overview : String? = viewModel?.getOverview(by: row)
            let data = viewModel?.getImageData(by: row)
            
            details.imageView.image = UIImage(data: data!)
            details.titleLabel.text = title
            details.overview.text = overview
        }
    }
