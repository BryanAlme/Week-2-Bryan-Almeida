//
//  DetailMovieViewController.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 11/04/2022.
//

import UIKit


class DetailMovieViewController: UIViewController {
    
    
    var imageView : UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.widthAnchor.constraint(equalToConstant: 200).isActive = true
        imageView.frame = CGRect(x: 0, y: 0, width: 100, height: 200)
        return imageView
    }()
    
    var titleLabel : UILabel = {
        let title = UILabel()
        return title
    }()
    var overview : UILabel = {
        let overview = UILabel()
        return overview
    }()
    
    
    var stackviewVertical : UIStackView = {
        let stackviewVertical = UIStackView()
        stackviewVertical.axis  = .vertical
        stackviewVertical.distribution  = .fillEqually
        stackviewVertical.alignment = .leading
        stackviewVertical.spacing = 10
        stackviewVertical.translatesAutoresizingMaskIntoConstraints = false
        return stackviewVertical
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(stackviewVertical)
        view.translatesAutoresizingMaskIntoConstraints = false
                
        let safeArea = view.safeAreaLayoutGuide
        
        let stackviewHorizontal = UIStackView ()
        stackviewHorizontal.axis  = .horizontal
        stackviewHorizontal.distribution  = .fillEqually
        stackviewHorizontal.alignment = .leading
        stackviewHorizontal.spacing = 10
        stackviewHorizontal.translatesAutoresizingMaskIntoConstraints = false
        stackviewHorizontal.addArrangedSubview(imageView)
        stackviewHorizontal.addArrangedSubview(titleLabel)
        stackviewHorizontal.addArrangedSubview(overview)
       

        stackviewVertical.addArrangedSubview(stackviewHorizontal)
        stackviewVertical.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        stackviewVertical.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        stackviewVertical.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        stackviewVertical.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        
    }
}

