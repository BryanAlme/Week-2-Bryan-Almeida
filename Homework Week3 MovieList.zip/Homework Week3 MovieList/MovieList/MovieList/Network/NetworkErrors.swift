//
//  NetworkErrors.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 07/04/2022.
//

import Foundation

enum  NetworkErrors : Error {
    
    case badURL
    case other(Error)
}
