//
//  NetworkUrls.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 07/04/2022.
//

import Foundation

enum NetworkURLs {
    
    static let urlBase = "https://api.themoviedb.org/3/movie/popular?language=en-US&page=1&api_key=6622998c4ceac172a976a1136b204df4"
    
    static let urlDetails = "https://api.themoviedb.org/3/movie/634649?api_key=6622998c4ceac172a976a1136b204df4"
}
