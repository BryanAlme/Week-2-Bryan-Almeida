//
//  loginViewController.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 07/04/2022.
//

import UIKit

class loginViewController : UIViewController {
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var completionHandler : ((String?)-> Void?)
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        userName.text = nil
    }
    
    
    @IBOutlet weak var userName: UITextField!
    @IBAction func saveButton(_ sender: Any) {
        
        NotificationCenter.default.post(name: Notification.Name("text"), object: userName.text)

        dismiss(animated: true, completion: nil)
        
 
    guard let username = userName.text, !username.isEmpty
                
    else{displayErrorAlert(message: "UserName are Empty")
            return}
    if username == "Bryan"  {
        performSegue(withIdentifier: "secondScreen", sender: nil)
    }else{
     displayErrorAlert(message: "UserName Incorrect")
    }
        
       
    
}
    private func displayErrorAlert(message: String){
        let alert = UIAlertController(title: "ERROR", message: message, preferredStyle: .alert)
        let acceptButton = UIAlertAction(title: "OK", style: .destructive, handler: nil)
        alert.addAction(acceptButton)
        present(alert, animated: true, completion: nil)
        
    }

}
