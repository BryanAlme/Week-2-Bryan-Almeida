//
//  ViewControllerViewModel.swift
//  MovieList
//
//  Created by Bryan Andres  Almeida Flores on 08/04/2022.
//

import Foundation
import Combine

protocol ViewControllerViewModelProtocol {
    var totalRows: Int { get }
    var publisherStories: Published<[Result]>.Publisher { get }
    var publisherCache: Published<[Int: Data]>.Publisher { get }
    func getStories()
    func getTitle(by row: Int) -> String?
    func getOverview(by row: Int) -> String?
    func getImageData(by row: Int) -> Data?
    func filterMovies(by searchTerm: String) -> Void
}

    class ViewControllerViewModel: ViewControllerViewModelProtocol?{
  
    
    var totalRows: Int { movies.count }
    var publisherMovies: Published<[Result]>.Publisher { $movies }
    var publisherCache: Published<[Int: Data]>.Publisher { $cache }

    
    private let networkManager: NetworkManager
    private var subscribers = Set<AnyCancellable>()
    
    @Published private(set) var movies = [Result]()
    @Published private(set) var filteredMovies = [Result]()
    @Published private var cache: [Int: Data] = [:]

    init(networkManager: NetworkManager) {
        self.networkManager = networkManager
    }
    
    func getTitle(by row: Int) -> String? {
        return movies[row].title
    }
    
    func getOverview(by row: Int) -> String? {
        return movies[row].overview
    }
    
    func getImageData(by row: Int) -> Data? {
        return cache[row]
    }
    
    
    func filterMovies(by searchTerm: String) -> Void {
        
        filterMovies(from: NetworkURLs.urlBase, searchTerm: searchTerm)

        
    }

    
    func getStories(){
        self.movies.removeAll()
        getStories(from: NetworkURLs.urlBase)
    }
    
    private func getStories(from url: String) {
        self.movies.removeAll()
        networkManager
            .getModel(Welcome.self, from: url)
            .sink { completion in
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                }
            } receiveValue: { [weak self] response in
                let temp = response.results
                
                for i in temp {
                    self?.movies.append(i)
                    self?.filteredMovies.append(i)
                }
                self?.downloadImages()
            }
            .store(in: &subscribers)
    }
    
    private func filterMovies(from url: String, searchTerm: String) {
        self.movies.removeAll()
        networkManager
            .getModel(Welcome.self, from: url)
            .sink { completion in
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                }
            } receiveValue: { [weak self] response in
                var temp = response.results
                temp = temp.filter({ (movie: Result ) -> Bool in
                    let match = movie.title.range(of: searchTerm, options: .caseInsensitive)
                    return match != nil
                })

                for i in temp {
                    self?.movies.append(i)
                }
                self?.downloadImages()
            }
            .store(in: &subscribers)
    }
    
    private func downloadImages() {
        var temp = [Int: Data]()
        let group = DispatchGroup()
        for (index, movie) in movies.enumerated() {
            let url: String? = NetworkURLs.urlBase + movie.posterPath
            if let image = url {
                group.enter()
                networkManager.getData(from: image) { data in
                    if let data = data {
                        temp[index] = data
                    }
                    group.leave()
                }
            }
        }
        group.notify(queue: .main) { [weak self] in
            self?.cache = temp
        }
    }
    
}
