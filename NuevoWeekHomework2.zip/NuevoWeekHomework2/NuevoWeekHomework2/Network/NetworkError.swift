//
//  NetworkError.swift
//  NuevoWeekHomework2
//
//  Created by Bryan Andres  Almeida Flores on 28/03/2022.
//

import Foundation

enum ErrorType:Error{
    case url
    case get(Error)
    case json(Error)
    case other(Error)
}

enum NetRespond<Success,Error>{
    case sucess(Success)
    case failure(Error)
    
}
