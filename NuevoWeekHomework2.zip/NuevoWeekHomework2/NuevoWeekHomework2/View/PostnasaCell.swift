//
//  PostnasaCell.swift
//  NuevoWeekHomework2
//
//  Created by Bryan Andres  Almeida Flores on 28/03/2022.
//

import Foundation
import UIKit


class PostnasaCell: UITableViewCell {
    
    static let identifier = " PostnasaCell "
    let imageLabel: UILabel = {
        let imageLabel = UILabel()
       imageLabel.translatesAutoresizingMaskIntoConstraints = false
       imageLabel.textColor = .blue
        imageLabel.numberOfLines = 0
        return imageLabel
    }()
    
    private let idLabel: UILabel = {
        let idLabel = UILabel()
        idLabel.translatesAutoresizingMaskIntoConstraints = false
       idLabel.textColor = . black
        idLabel.numberOfLines = 0
        return idLabel
        
    }()
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpUI()

     }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setUpUI (){
        self.contentView.addSubview(idLabel)
        self.contentView.addSubview(imageLabel)
        let safeArea = contentView.safeAreaLayoutGuide
        
        
        idLabel.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        idLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        idLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        
       imageLabel.topAnchor.constraint(equalTo: idLabel.bottomAnchor).isActive = true
        imageLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        imageLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
       imageLabel.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCell ( id : Int , status : Bool ){
        idLabel.text = "ID:\(id)                                                                 ➡   "
        imageLabel.text = "status:\(status)"
    }
    
}
