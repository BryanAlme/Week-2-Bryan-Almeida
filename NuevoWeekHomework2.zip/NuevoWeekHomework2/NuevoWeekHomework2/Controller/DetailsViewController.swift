//
//  DetailsViewController.swift
//  NuevoWeekHomework2
//
//  Created by Bryan Andres  Almeida Flores on 28/03/2022.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var data:nasaAPI?
    var recall:((Bool)->Void)?
    
    private let topLabel:UILabel = {
        let topUpLabel = UILabel()
        topUpLabel.translatesAutoresizingMaskIntoConstraints = false
        topUpLabel.text = "Favorite"
        topUpLabel.font = UIFont.systemFont(ofSize: 30)
        return topUpLabel
    }()
    
    private let switchOnOff:UISwitch = {
        let switchOnOff = UISwitch()
        switchOnOff .translatesAutoresizingMaskIntoConstraints = false
        switchOnOff .addTarget(DetailsViewController.self, action: #selector(switchStatus),for: UIControl.Event.valueChanged)
        return switchOnOff
    }()
    
    private let imageJason:UIImageView = {
        let ImageJson = UIImageView()
        ImageJson .translatesAutoresizingMaskIntoConstraints = false
        ImageJson .backgroundColor = .black
        ImageJson .contentMode = .center
        return ImageJson
    }()
    
    
    override func viewDidLoad() {
    
        setupUI()
        populate()
    }
    private func setupUI(){
        
        view.addSubview(topLabel)
        view.addSubview(switchOnOff)
        view.addSubview(imageJason)
        switchOnOff.isOn = data?.status ?? false
        
            let safeArea = view.safeAreaLayoutGuide
            topLabel.translatesAutoresizingMaskIntoConstraints = false
            topLabel.topAnchor.constraint(equalTo: safeArea.topAnchor,constant:30).isActive = true
            topLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
            topLabel.heightAnchor.constraint(equalTo: switchOnOff.heightAnchor).isActive = true
            
        
           switchOnOff.translatesAutoresizingMaskIntoConstraints = false
           switchOnOff.topAnchor.constraint(equalTo: safeArea.topAnchor,constant:30).isActive = true
           switchOnOff.leadingAnchor.constraint(equalTo: topLabel.trailingAnchor).isActive = true
        
        
        imageJason.translatesAutoresizingMaskIntoConstraints = false
        imageJason.topAnchor.constraint(equalTo: topLabel.bottomAnchor,constant: 80).isActive = true
        imageJason.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        imageJason.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        imageJason.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor,constant: 80).isActive = true
        
           
            
    }
    
  
    private func populate(){
        guard let data = self.data, let url=URL(string:data.img_src)
        else{return}
        DispatchQueue.global().async {[weak self] in
            do{
                let imgData = try Data(contentsOf: url)
                DispatchQueue.main.async {
                    self?.imageJason.image = UIImage(data:imgData)
                }
            }catch(let example){
                print(example.localizedDescription)
            }
        }

    }
    
 
    @objc private func switchStatus(){
        self.data?.status = switchOnOff.isOn
        self.recall?(self.data?.status ?? false)
        
        
    }
}
