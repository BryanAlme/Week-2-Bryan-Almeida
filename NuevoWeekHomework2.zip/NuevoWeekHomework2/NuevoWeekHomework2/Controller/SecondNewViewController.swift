//
//  SecondNewViewController.swift
//  NuevoWeekHomework2
//
//  Created by Bryan Andres  Almeida Flores on 30/03/2022.
//

import UIKit

class SecondViewController: UIViewController {

  
    
    private let topLabel:UILabel = {
        let topUpLabel = UILabel()
        topUpLabel.translatesAutoresizingMaskIntoConstraints = false
        topUpLabel.text = "Favorite"
        topUpLabel.font = UIFont.systemFont(ofSize: 30)
        return topUpLabel
    }()
    
    private let switchOnOff:UISwitch = {
        let switchOnOff = UISwitch()
        switchOnOff .translatesAutoresizingMaskIntoConstraints = false
        return switchOnOff
    }()
    
    private let imageJason:UIImageView = {
        let ImageJson = UIImageView()
        ImageJson .translatesAutoresizingMaskIntoConstraints = false
        ImageJson .backgroundColor = .black
        ImageJson .contentMode = .center
        return ImageJson
    }()
    
    
    
    
    
    var link: String?
    var switchStatus = false
    
    private lazy var switchAction: UIAction = UIAction { [weak self] _ in
        self?.returnMasterViewController()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        switchOnOff.isOn = switchStatus
        if let urlString = link {
            let split = urlString.split(separator: ":")
            getImage(split[0] + "s:" + split[1])
        }
        switchOnOff.addTarget(self, action: #selector(returnMasterViewController), for: .touchUpInside)
        
    }
    
    @objc private func returnMasterViewController() {
        switchStatus = switchOnOff.isOn
        
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: false) { [weak self] _ in
            self?.performSegue(withIdentifier: "returnToMainScreen", sender: nil)
        }
    }
    
    func getImage(_ urlString: String) {
        
        guard let url = URL(string: urlString)
        else {
            return
        }
        do {
            let data1 = try Data(contentsOf: url)
            DispatchQueue.main.async {
                self.imageJason.image = UIImage(data: data1)
            }
        } catch let error {
            print(error.localizedDescription)
        }
        
    }
    
}



