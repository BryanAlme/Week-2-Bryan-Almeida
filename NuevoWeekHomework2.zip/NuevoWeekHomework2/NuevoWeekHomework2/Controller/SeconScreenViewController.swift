//
//  SeconScreenViewController.swift
//  NuevoWeekHomework2
//
//  Created by Bryan Andres  Almeida Flores on 29/03/2022.
//

import UIKit

class SeconScreenViewController: UIViewController {

    private var currentRow:Int?
    
    private var post:[nasaAPI] = [nasaAPI]()
    
    private lazy var tabView:UITableView = {
        let tb = UITableView()
        tb.dataSource = self
        tb.delegate = self
        tb.register(PostnasaCell.self, forCellReuseIdentifier: PostnasaCell.identifier)
        tb.translatesAutoresizingMaskIntoConstraints = false
        return tb
    }()
    override func viewWillDisappear(_ animated: Bool) {
        saveData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    
        setupUI()
     
        if self.post.isEmpty{
            var EmptyData = true
            let data = UserDefaults.standard.data(forKey: "data")
            if let data = data,let decodeData = try? JSONDecoder().decode([nasaAPI].self, from: data){
                self.post = decodeData
                EmptyData = false
            }
            
            if EmptyData{
                networkError{[weak self] res in
                    switch res{
                    case .failure(let error):
                        print(error.localizedDescription)
                    case .sucess(let data):
                        DispatchQueue.main.async {
                            self?.post = data
                            self?.tabView.reloadData()
                        }
                    }
                }
            }
            
        }
    }
    
    private func setupUI(){
        
        view.addSubview(tabView)
        
        let safeArea = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            tabView.topAnchor.constraint(equalTo:safeArea.topAnchor),
            tabView.leadingAnchor.constraint(equalTo:safeArea.leadingAnchor),
            tabView.trailingAnchor.constraint(equalTo:safeArea.trailingAnchor),
            tabView.bottomAnchor.constraint(equalTo:safeArea.bottomAnchor),
            ])
    }
    private func saveData(){
        if let currentR = self.currentRow{print("save data: ",self.post[currentR].status as Any)}
        let encodeData = try! JSONEncoder().encode(self.post)
        UserDefaults.standard.set(encodeData, forKey: "data")
    }
    

}

extension SeconScreenViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return post.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: PostnasaCell.identifier, for: indexPath) as! PostnasaCell
        let row = indexPath.row
        let data = self.post[row]
        if data.status == true{
            cell.imageLabel.textColor = .green
        }
        cell.configureCell(id:data.id,status:data.status ?? false)
        return cell
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        print("deselect")
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("select")
        let row = indexPath.row
        currentRow = row
       
        
        
        performSegue(withIdentifier: "pageTwo", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "pageTwo"{
            let destination = segue.destination as! DetailsViewController
            guard let currentRow = self.currentRow else{return}
            destination.data = self.post[currentRow]
            destination.recall = {[weak self] status in
                self?.post[currentRow].status = status
                self?.tabView.reloadData()
                self?.saveData()
            }
        }
    }
    @IBAction func returnViewController(_ segue:UIStoryboardSegue){
        
    }
    
    
    
}
