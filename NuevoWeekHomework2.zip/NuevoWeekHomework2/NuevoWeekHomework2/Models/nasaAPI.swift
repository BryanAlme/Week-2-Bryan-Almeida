//
//  nasaAPI.swift
//  NuevoWeekHomework2
//
//  Created by Bryan Andres  Almeida Flores on 28/03/2022.
//

import Foundation

struct nasaAPI:Codable{
    let id:Int
    var status:Bool?
    let img_src:String

    enum CodingKeys:String,CodingKey{
        case id
        case status
        case img_src
    }
}

struct photos:Decodable{
    let photos:[nasaAPI]
}
