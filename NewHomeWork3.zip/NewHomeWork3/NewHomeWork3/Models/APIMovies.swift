//
//  APIMovies.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 12/04/2022.
//

import UIKit

struct ApiResultsMovie: Codable {
    let id:Int
    let posterPath:String?
    let title:String
    let overview:String
    var favorite:Bool?
    let page:Int
    let results:[ApiResultsMovie]
    
}

        enum CodingKeys:String, CodingKey{
            case id
            case posterPath = "poster_path"
            case overview
            case title
        }


struct MovieDetailModel:Codable{
    let id:Int
    let posterPath:String?
    let title:String
    let overview:String
    let productionCompanies:[ProductionCompany]
    
    enum CodingKeys:String, CodingKey{
        
        case id
        case posterPath = "poster_path"
        case title
        case overview
        case productionCompanies = "production_companies"
    }
}

struct ProductionCompany:Codable{
    let id:Int
    let logoPath:String?
    let name:String
    let country:String
    var logoData:Data?
    
    enum CodingKeys:String, CodingKey{
        case id
        case logoPath = "logo_path"
        case name
        case country = "origin_country"
    }
}
