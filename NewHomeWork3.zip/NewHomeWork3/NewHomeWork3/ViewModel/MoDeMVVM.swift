//
//  MoDeMVVM.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 18/04/2022.
//

import UIKit

class ConfigureMVVM{
    static func configure(_ mainViewController:MainViewController){
        let networkManager = NetworkManager()
        let repository = Repository(networkManager)
        
        let viewviewModel = MovieViewModel(repository: repository)
      mainViewController.viewModel = viewviewModel
        let principalTableView = PrincipalTableView (controller: mainViewController)
       mainViewController.tableView = principalTableView
        
    }
}
