//
//  MovieViewModel.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 18/04/2022.
//

import Foundation

class MovieViewModel{
    @Published var movieData:[ApiResultsMovie] = [ApiResultsMovie]()
    @Published var posterData = [Int:Data]()
    var user:String?
    
    var moviePublisher:Published<[ApiResultsMovie]>.Publisher{$movieData}
    var posterPublisher:Published<[Int:Data]>.Publisher{$posterData}
    
    let repository:Repository
    private var isLoading = false
    
    private var page = 1
   
    init(repository:Repository){
        self.repository = repository
    }
    
    func loadMoreData(){
        page += 1
        loadData(isAppend: true)
    }
    func loadData(isAppend:Bool=false){
        guard !isLoading else{return}
        isLoading = true
        repository.getMovieData(page:page){ [weak self] result in
            switch result{
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let data):
                if let self = self{
                    if isAppend{
                        self.movieData.append(contentsOf:data)
                    }else{
                        self.movieData = data
                    }
                    self.repository.updateMovie(user:self.user,movieData:&self.movieData)
                    self.updateImageData()
                    self.isLoading = false
                }
            }
        }
    }
    private func updateImageData(){
        var tempImageData = posterData
        let group = DispatchGroup()
        for movie in movieData{
            if posterData[movie.id] == nil,let posterPath = movie.posterPath{
                group.enter()
                repository.getPosterData(from:NetworkURLs.imageURL){ result in
                    switch result{
                    case .success(let data):
                        tempImageData[movie.id] = data
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                    group.leave()
                }
            }
        }
        group.notify(queue: .main){[weak self] in
            self?.posterData = tempImageData
        }
    }
    func forceUpdate(){
        movieData = []
        posterData = [:]
        repository.removeAllData()
        page = 1
        loadData()
    }
    func deleteData(row:Int){
        movieData.remove(at:row)
        if posterData[row] != nil{
            posterData.removeValue(forKey: row)
        }
    }
    func getMovieData(by row:Int) -> ApiResultsMovie?{
        guard row < movieData.count else {return nil}
        return movieData[row]
    }
    func saveMovieData(){
        self.repository.saveMovie(user:user,movieData:movieData)
    }
    func updateFavor(_ isOn:Bool, _ id:Int){
        let index = self.movieData.firstIndex(where: {
            $0.id == id
        })
        self.movieData[index!].favorite = isOn
        self.saveMovieData()
    }
}
