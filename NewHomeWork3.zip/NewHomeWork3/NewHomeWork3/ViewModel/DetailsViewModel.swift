//
//  File.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 18/04/2022.
//

import Foundation
import UIKit

class DetailViewModel{
    @Published var detailData:MovieDetailModel?
    var posterData:Data?
    var companies:[ProductionCompany]?
    var movieData:ApiResultsMovie
    
    private let repository:Repository
    
    init(movieData:ApiResultsMovie,repository:Repository){
        self.repository = repository
        self.movieData = movieData
    }
    
    func loadData(detailVC:DetailsViewViewController){
        repository.getMovieDetailsData(movieData.id){ [weak self] data in
            if let self = self{
                DispatchQueue.main.async {
                    detailVC.titleLabel.text = data.title
                    detailVC.detailsLabel.text = data.overview
                }
                if let path = data.posterPath{
                    self.repository.getPosterData(from:NetworkURLs.imageURL){[weak self] result in
                        switch result{
                        case .failure(let e):
                            print(e.localizedDescription)
                        case .success(let image):
                            let imagview = UIImageView(image: UIImage(data:image))
                            DispatchQueue.main.async {
                                detailVC.ImageVi = imagview
                            }
                        }
                    }
                }
            
            }
        }

        
    }

    func updateCompanyData(detailData:MovieDetailModel,_ detailVC:DetailsViewViewController){
        self.companies = detailData.productionCompanies
        let group = DispatchGroup()
        for (pos,company) in companies!.enumerated(){
            if let logoPath = company.logoPath{
                group.enter()
                repository.getPosterData(from:NetworkURLs.imageURL){ [weak self] result in
                    switch result{
                    case .success(let data):
                        self?.companies?[pos].logoData = data
                        
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                    group.leave()
                }
            }
        }
      
        group.notify(queue: .main){
            DispatchQueue.main.async {
                detailVC.collection.reloadData()
            }
        }
    }
}

