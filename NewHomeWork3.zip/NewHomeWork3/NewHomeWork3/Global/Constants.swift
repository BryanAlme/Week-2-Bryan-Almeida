//
//  File.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 18/04/2022.
//

import Foundation

enum Constants {

static let greetPrefix = "Hello:"
static let defaultNameKey = "name"
    static let editIcon = "square.and.pencil"
    
}

enum NormError:Error{
    case userNameError(String)
}

enum SegmentType:Int,CaseIterable{
    case MovieList = 0
    case Favorites
    var name:String{
        switch self{
        case .MovieList:
            return "Movie list"
        case .Favorites:
            return "Favorites"
        }
    }
    
    var position:Int{
        self.rawValue
    }
}
