//
//  MainTableView.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 18/04/2022.
//

import UIKit
import Combine

class PrincipalTableView:UITableView{
    private let controller:MainViewController
    let viewModel:MovieViewModel
    private var subscribers = Set<AnyCancellable>()
    private var tmpMovieData = [ApiResultsMovie]()
    var segmentType:SegmentType = SegmentType.MovieList
    
    func setSegmentType(_ segmentType:SegmentType){
        self.segmentType = segmentType
        self.updateMovieData()
        self.reloadData()
    }
    
    var searcher = UISearchController(searchResultsController: nil)

    init(controller:MainViewController){
        self.controller = controller
        self.viewModel = controller.viewModel!
        super.init(frame: .zero, style: .plain)
        setupUI()
        self.dataSource = self
        self.prefetchDataSource = self
        self.register(CustomeTableViewCell.self, forCellReuseIdentifier: CustomeTableViewCell.identifier)
        self.rowHeight = UITableView.automaticDimension
        addBindings()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var textField:UITextField = {
        let textField = UITextField()
        textField.leftView = UIImageView(image:UIImage(systemName:"magnifyingglass"))
        return textField
    }()
    
    private func setupUI(){
       
        searcher.hidesNavigationBarDuringPresentation = false
        searcher.searchBar.delegate = self
        searcher.searchBar.sizeToFit()
        tableHeaderView = searcher.searchBar
        
    }
    private func addBindings(){
        viewModel.moviePublisher
            .dropFirst()
            .receive(on: RunLoop.main)
            .sink{[weak self] (res:Any) in
                self?.reloadData()
            }.store(in: &subscribers)
        viewModel.posterPublisher
            .dropFirst()
            .receive(on: RunLoop.main)
            .sink{[weak self] (res:Any) in
                self?.updateMovieData()
                //self?.reloadData()
            }.store(in: &subscribers)
    }
    // MARK: KEY UPDATE FUNCTION
    func updateMovieData(filerText:String?=nil){
        self.tmpMovieData = controller.segmentType == SegmentType.Favorites ? viewModel.movieData.filter{$0.favorite ?? false} : viewModel.movieData
        if let filerText = filerText {
            self.tmpMovieData = tmpMovieData .filter{$0.title.lowercased().contains(filerText.lowercased()) || ($0.overview.lowercased().contains(filerText.lowercased()))
            }
        }else{
        }
        self.reloadData()
        
    }
}

extension PrincipalTableView:UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText != ""{
            updateMovieData(filerText: searchText)
        }else{
            updateMovieData()
        }
    }
}

extension PrincipalTableView:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tmpMovieData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let cell = dequeueReusableCell(withIdentifier:CustomeTableViewCell.identifier, for: indexPath)
        if let cell = cell as? CustomeTableViewCell{
            let data = viewModel.movieData[row]
            cell.configure(in:data)
            if let imageData = viewModel.posterData[data.id]{
                cell.setPosterView(in: imageData)
            }
            cell.detailButton.tag = row
            cell.detailButton.addTarget(self, action: #selector(callDetail(sender:)), for: .touchUpInside)
        }
        return cell
    }
    
    @objc private func callDetail(sender:UIButton){
        let details = DetailsViewViewController(tmpMovieData[sender.tag],repository: viewModel.repository)
        details.parentView = self
        details.row = sender.tag
        searcher.searchBar.isHidden = true
        if let navigation = controller.navigationController{
            navigation.title = "Movies"
            navigation.navigationBar.topItem?.title = "Movies"
            navigation.navigationItem.backBarButtonItem?.title = "Movies"
            navigation.navigationItem.backButtonTitle = "Movies"
            navigation.pushViewController(details, animated: true)
        }
    }
    func setFavor(_ isOn:Bool, _ id:Int){
        self.viewModel.updateFavor(isOn,id)
        updateMovieData()
    
    }
    
}

extension PrincipalTableView:UITableViewDataSourcePrefetching{
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        let rows = indexPaths.map{$0.row}
        if rows.contains(viewModel.movieData.count-1){
            viewModel.loadMoreData()
        }
    }
    
    
}
