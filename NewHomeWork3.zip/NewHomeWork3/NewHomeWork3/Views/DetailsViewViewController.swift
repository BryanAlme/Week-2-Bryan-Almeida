//
//  DetailsViewViewController.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 16/04/2022.
//

import UIKit

class DetailsViewViewController: UIViewController {
    
    static let identiferCell = "viewCell"
    private var detailViewModel:DetailViewModel
    var parentView:PrincipalTableView?
    var row:Int?
    
    var arrayImages = [Data]()
    
    
    var ImageVi:UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    let titleLabel:UILabel = {
        let label = UILabel()
        label.text = "label"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 18)
        return label
    }()
    
    let companyTitleLabel:UILabel = {
        let label = UILabel()
        label.text = "Production companies"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 10
        label.font = UIFont.boldSystemFont(ofSize: 22)
        return label
    }()
    
    let detailsLabel:UILabel = {
        let label = UILabel()
        label.text = "overview"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 50
        return label
    }()
    
    lazy var collection:UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        let screensize = UIScreen.main.bounds.size
        layout.itemSize = CGSize(width:screensize.width/2, height:screensize.height/4)
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.isPagingEnabled = true
        collection.translatesAutoresizingMaskIntoConstraints = false
        collection.register(UICollectionViewCell.self, forCellWithReuseIdentifier: DetailsViewViewController.identiferCell)
        collection.backgroundColor = .lightGray
        collection.dataSource = self
        collection.delegate = self
        
        collection.backgroundColor = .white
        return collection
    }()
    
    init(_ data:ApiResultsMovie,repository:Repository){
        
        self.detailViewModel = DetailViewModel(movieData: data,repository: repository)
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        configure()
        if let navigation = self.navigationController{
            navigation.isNavigationBarHidden = false
            navigation.navigationBar.topItem?.title = titleLabel.text
            navigation.navigationItem.hidesBackButton = true
            navigation.navigationBar.topItem?.backButtonTitle = "Movies"
            let switcher = UISwitch()
            switcher.addTarget(self, action: #selector(switchFavor(sender:)), for: .valueChanged)
            switcher.isOn = self.detailViewModel.movieData.favorite ?? false
            let switcherBarItem = UIBarButtonItem(customView: switcher)
            navigation.navigationBar.topItem?.rightBarButtonItem = switcherBarItem
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        
    }

    private func configure(){
      
        parentView?.viewModel.repository.getMovieDetailsData(detailViewModel.movieData.id){ [weak self] data in
            if let self = self{
                DispatchQueue.main.async {
                    self.titleLabel.text = data.title
                    self.detailsLabel.text = data.overview
                    if data.posterPath != nil{

                        self.parentView?.viewModel.repository.getPosterData(from:NetworkURLs.imageURL){[weak self] result in
                            switch result{
                            case .failure(let e):
                                print(e.localizedDescription)
                            case .success(let image):
                                let image =  UIImage(data:image)
                                DispatchQueue.main.async {
                                    self?.ImageVi.image = image
                                }
                            }
                        }
                    }
                    // update companies
                    self.detailViewModel.updateCompanyData(detailData: data,self)
                    self.collection.reloadData()
                }
            }}
    }
    
    private func setupUI(){
        view.backgroundColor = .white
        view.addSubview(ImageVi)
        view.addSubview(titleLabel)
        view.addSubview(detailsLabel)
        view.addSubview(collection)
        view.addSubview(companyTitleLabel)
        
        let safeArea = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            ImageVi.heightAnchor.constraint(equalToConstant: 300),
           ImageVi.topAnchor.constraint(equalTo: safeArea.topAnchor),
            ImageVi.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
           ImageVi.widthAnchor.constraint(equalToConstant: 200),
            ImageVi.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
            titleLabel.topAnchor.constraint(equalTo: safeArea.topAnchor,constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: ImageVi.trailingAnchor,constant: 10),
            titleLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),

            detailsLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor),
            detailsLabel.leadingAnchor.constraint(equalTo: ImageVi.trailingAnchor,constant:10),
            detailsLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),
            detailsLabel.bottomAnchor.constraint(equalTo: ImageVi.bottomAnchor),

            companyTitleLabel.topAnchor.constraint(equalTo: ImageVi.bottomAnchor,constant: 10),
            companyTitleLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor,constant:10),

            collection.topAnchor.constraint(equalTo: companyTitleLabel.bottomAnchor),
            collection.heightAnchor.constraint(equalToConstant: UIScreen.main.bounds.width/3),
            collection.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor,constant:10),
            collection.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),

        ])
    }

    @objc func switchFavor(sender:UISwitch){
        parentView?.setFavor(sender.isOn, self.detailViewModel.movieData.id)
    }
}

extension DetailsViewViewController:UICollectionViewDataSource,UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        detailViewModel.companies?.count ?? 0
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView,
                          layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CGSize(width: 100, height: 100)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let cell = collection.dequeueReusableCell(withReuseIdentifier: DetailsViewViewController.identiferCell, for: indexPath)
        let company = detailViewModel.companies![row]
        let imageView = UIImageView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width/2,height:UIScreen.main.bounds.height/4))
        imageView.contentMode = .scaleAspectFit
        if let data = company.logoData {
            ImageVi.image = UIImage(data:data)
        }
        let nameLabel = UILabel.init(frame: CGRect(x:0,y:150,width:200,height:20))
        nameLabel.text = company.name
        nameLabel.textAlignment = .center
        cell.addSubview(imageView)
        cell.addSubview(nameLabel)
        return cell
    }
    
    
    
}
