//
//  ViewController.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 12/04/2022.
//
import UIKit
import Combine

class MainViewController: UIViewController{
    var viewModel:MovieViewModel?
    var tableView:PrincipalTableView?


    private lazy var refreshAction:UIAction = UIAction{[weak self] _ in
        self?.viewModel?.forceUpdate()
        self?.refreshControl.endRefreshing()
        self?.tableView?.reloadData()
    }
    private lazy var refreshControl:UIRefreshControl = {
        let refresh = UIRefreshControl(frame: .zero, primaryAction: refreshAction)
        return refresh
    }()


    var nameLabel:UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = Constants.greetPrefix
        label.font = UIFont.boldSystemFont(ofSize: 20)
        return label
    }()

    var editIconVC:UIImageView = {
        let editIcon = UIImageView(image: UIImage(systemName:"square.and.pencil"))
        editIcon.translatesAutoresizingMaskIntoConstraints = false
        return editIcon
    }()
    var editIconButton:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(systemName:"square.and.pencil"), for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(MainViewController.self, action: #selector(changeName), for: .touchUpInside)
        return button
    }()

    lazy var segments:UISegmentedControl = {
        let segment = UISegmentedControl()
        segment.translatesAutoresizingMaskIntoConstraints=false
        for item in SegmentType.allCases{
            segment.insertSegment(withTitle: item.name, at: item.position, animated: true)

        }
        segment.selectedSegmentIndex = 0
        segment.addTarget(self, action: #selector(setSegmentType), for: .valueChanged)
        return segment
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        try? configure()
        setupUI()


    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.topItem?.title = "Movies"
        self.navigationController?.isNavigationBarHidden = true
        tableView?.searcher.searchBar.isHidden = false
        let name = UserDefaults.standard.string(forKey: Constants.defaultNameKey)
        if let name = name{
            nameLabel.text = Constants.greetPrefix + name
            self.viewModel?.user = name
            self.tableView?.viewModel.loadData()
            self.tableView?.updateMovieData()
        }else{
            print(NormError.userNameError("user not save in UserDefaults"))
        }
    }
    private func configure() throws{
        ConfigureMVVM.configure(self)


    }
    private func setupUI(){
        view.backgroundColor = .white
        view.addSubview(nameLabel)
        view.addSubview(editIconButton)
        view.addSubview(segments)
        self.tableView?.addSubview(refreshControl)

        let safeArea = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: safeArea.topAnchor),
            nameLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor,constant: 20),
            editIconButton.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor,constant: -20),
            editIconButton.heightAnchor.constraint(equalTo: nameLabel.heightAnchor),
            editIconButton.centerYAnchor.constraint(equalTo: nameLabel.centerYAnchor),

            segments.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
            segments.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),
            segments.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),

        ])
        if let tableView = self.tableView {
            view.addSubview(tableView)
            tableView.translatesAutoresizingMaskIntoConstraints = false
            tableView.topAnchor.constraint(equalTo: segments.bottomAnchor).isActive = true
            tableView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
            tableView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
            tableView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        }
    }

    @objc private func changeName(){
        self.navigationController?.popViewController(animated: true)
        let change = LoginViewController()


    }

    var segmentType = SegmentType.MovieList

    @objc private func setSegmentType(){
        let segmentType = SegmentType(rawValue:segments.selectedSegmentIndex  )
        self.segmentType = segmentType!
        if let view = self.tableView{
            view.updateMovieData()
        }
    }
}







