//
//  LoginViewController.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 12/04/2022.
//

import UIKit


protocol EditNameDelegate: AnyObject {
    func editName()
}

public class LoginViewController: UIViewController {

weak var delegate: EditNameDelegate?

private let defaults = UserDefaults.standard

var nameTextField: UITextField = {
    let textField = UITextField()
    textField.placeholder = "Write your name here."
    textField.borderStyle = .roundedRect
    textField.layer.cornerRadius = 5
    return textField
}()

lazy var saveButton: UIButton = {
    let button = UIButton()
    button.setTitle("Save", for: .normal)
    button.setTitleColor(.blue, for: .normal)
    button.addTarget(self, action: #selector(saveButtonAction), for: .touchUpInside)
    return button
}()

    public override func viewDidLoad() {
    super.viewDidLoad()
    setUpUI()
    
}

private func setUpUI() {
    view.backgroundColor = .white
    view.addSubview(nameTextField)
    view.addSubview(saveButton)
    
    let safeArea = view.safeAreaLayoutGuide
    
    nameTextField.translatesAutoresizingMaskIntoConstraints = false
    nameTextField.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 10).isActive = true
    nameTextField.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: -10).isActive = true
    nameTextField.centerXAnchor.constraint(equalTo: safeArea.centerXAnchor).isActive = true
    nameTextField.centerYAnchor.constraint(equalTo: safeArea.centerYAnchor).isActive = true

    saveButton.translatesAutoresizingMaskIntoConstraints = false
    saveButton.trailingAnchor.constraint(equalTo: nameTextField.trailingAnchor).isActive = true
    saveButton.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 10).isActive = true
}
@objc private  func saveButtonAction(){

        if let name = nameTextField.text {
            if name.count > 2 {
                let mainScreen = MainViewController()
                mainScreen.modalPresentationStyle = .fullScreen
                self.defaults.set(name, forKey:Constants.defaultNameKey)
                
                let navController = UINavigationController(rootViewController: mainScreen)
                navController.modalPresentationStyle = .fullScreen
                
                self.present(navController, animated: true)
            } else {
                let alert = UIAlertController(title: "Atention!!", message: "More than 3 Characters, Please", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    return
            }
        }
    }
}
    

     


