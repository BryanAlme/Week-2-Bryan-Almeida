//
//  MainTableViewCell.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 18/04/2022.
//

import UIKit
import Combine

class CustomeTableViewCell:UITableViewCell{
    static let identifier = "CustomeTableViewCell"
    
    let posterImageView:UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    let titleLabel:UILabel = {
        let label = UILabel()
        label.text = "label"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 22)
        return label
    }()
    
    let overviewLabel:UILabel = {
        let label = UILabel()
        label.text = "overview"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 6
        return label
    }()
    
    let likeLabel:UILabel = {
        let label = UILabel()
        label.text = "click"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let detailButton:UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.configuration = UIButton.Configuration.filled()
        button.backgroundColor = .blue
        button.setTitle("Show Details", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize:20)
        button.sizeToFit()
        
        return button
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   
    
    private func setupUI(){
  
        self.contentView.addSubview(posterImageView)
        self.contentView.addSubview(titleLabel)
        self.contentView.addSubview(overviewLabel)
        self.contentView.addSubview(likeLabel)
        self.contentView.addSubview(detailButton)
        
        let safeArea = contentView.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            detailButton.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor,constant: -5),
            detailButton.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor,constant:-10),
            detailButton.leadingAnchor.constraint(equalTo: likeLabel.leadingAnchor,constant:-40),
            
            posterImageView.topAnchor.constraint(equalTo: safeArea.topAnchor,constant: 5),
            posterImageView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
            posterImageView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor,constant: 5),
            posterImageView.heightAnchor.constraint(equalToConstant: 230),
            posterImageView.widthAnchor.constraint(equalToConstant: 140),
            
            likeLabel.bottomAnchor.constraint(equalTo: detailButton.topAnchor,constant:-10),
            likeLabel.trailingAnchor.constraint(equalTo: detailButton.trailingAnchor),
            
            titleLabel.topAnchor.constraint(equalTo: safeArea.topAnchor,constant: 25),
            titleLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),
            
            overviewLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor,constant: 5),
            overviewLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor),
            overviewLabel.trailingAnchor.constraint(equalTo: detailButton.leadingAnchor),
        
            
        ])
    }
    
    func configure(in movie:ApiResultsMovie){
        titleLabel.text = movie.title
        overviewLabel.text = movie.overview
        likeLabel.isHidden = !(movie.favorite ?? false)
        posterImageView.image = nil
        
        
    }
    func setPosterView(in data:Data){
        posterImageView.image = UIImage(data: data)
    }
    

}

