//
//  MovieCoreData.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 17/04/2022.
//

import Foundation

import Foundation
import CoreData

class MovieCoreData{
    static var context:NSManagedObjectContext {
        let container = NSPersistentContainer(name: "MovieCoreData")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        let context = container.viewContext
        return context
    }
}
