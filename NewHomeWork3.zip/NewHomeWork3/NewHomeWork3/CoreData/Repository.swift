//
//  Repository\.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 17/04/2022.
//

import Foundation
import Combine
import CoreData

class Repository{

    
    private lazy var context = MovieCoreData.context
    private var page = 1
    private let networkManager:NetworkManager
    private var subscribers = Set<AnyCancellable>()
    init(_ networkManager:NetworkManager){
        self.networkManager = networkManager
    }
    
    func getMovieData(page:Int,_ completionHandler: @escaping (Result<[ApiResultsMovie], NetworkError>)->Void){
        networkManager.getModel(ApiResultsMovie.self, url:  NetworkURLs.movieURL)
            .sink{_ in} receiveValue:{ data in
                let movieData = data.results
                completionHandler(.success(movieData))
            }.store(in: &subscribers)
    }
    func getMovieDetailsData(_ id:Int,_ completionHandler: @escaping (MovieDetailModel)->Void){
        networkManager.getModel(MovieDetailModel.self, url: NetworkURLs.detailURL, completionHandle: completionHandler)
    }
    func getPosterData(from url:NetworkURLs, _ completionHandler: @escaping (Result<Data,NetworkError>)->Void){
        networkManager.getPosterImage(url: url){ data in
            if let data = data{
                completionHandler(.success(data))
            }else{
                completionHandler(.failure(NetworkError.badURL))
            }
        }
    }
    
    func saveMovie(user:String?,movieData:[ApiResultsMovie]){
        if let user = user{
            var favorIds:[Int] = movieData.filter{$0.favorite ?? false}.map{$0.id}
            guard let fetchDesc = NSEntityDescription.entity(forEntityName: "Favourite", in: context) else{return}
            let fetchRequest = Favourite.fetchRequest()
            do{
                fetchRequest.predicate = NSPredicate(format:"user=%@",user)
                let fetchResult = try context.fetch(fetchRequest)
                for result in fetchResult{
                    let rid = Int(result.id)
                    if favorIds.contains(rid){
                        
                    }else{
                       context.delete(result)
                    }
                    if let index = favorIds.firstIndex(of: rid){
                        favorIds.remove(at: index)
                    }
                }
            
                if favorIds.count != 0{
                    for rid in favorIds{
                        let newFavor = Favourite(entity: fetchDesc, insertInto: context)
                        newFavor.setValue(Int64(rid),forKey: "id")
                        newFavor.setValue(user,forKey: "user")
                        }
                }
                try context.save()
            }catch (let error){
                print(error.localizedDescription)
            }
        }
    }
    func updateMovie(user:String?,movieData:inout [ApiResultsMovie]){
        
        if let user = user{
            let fetchRequest = Favourite.fetchRequest()
            do{
                for (pos,oneMovie) in movieData.enumerated(){
                    fetchRequest.predicate = NSPredicate(format:"user=%@ && id=%d",user,oneMovie.id)
                    let fetchResult = try context.fetch(fetchRequest)
                    if fetchResult.count == 0{
                        
                    }else{
                        movieData[pos].favorite = true
                    }
                }
                try context.save()
            }catch (let error){
                print(error.localizedDescription)
            }
        }
    }
    
    func removeAllData() {
        let request:NSFetchRequest = Favourite.fetchRequest()
        do{
            let posts = try context.fetch(request)
            for post in posts{
                context.delete(post)
            }
            try context.save()
        }catch(let error){
            print(error.localizedDescription)
        }
    }
}

