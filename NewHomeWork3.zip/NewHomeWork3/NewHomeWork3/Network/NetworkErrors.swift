//
//  NetworkErrors.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 12/04/2022.
//

import Foundation

enum NetworkError:Error{
    case badURL
    case decodeError(Error)
    case netError(Error)
    case other(Error)
}
