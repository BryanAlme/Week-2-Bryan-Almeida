//
//  NetworkUrls.swift
//  NewHomeWork3
//
//  Created by Bryan Andres  Almeida Flores on 12/04/2022.
//

import Foundation


enum NetworkURLs {
    
   // static let imageUrlBase = "https://image.tmdb.org/t/p/w500"
    
    case movieURL
    case detailURL
    case imageURL
    
    var url:String{
        switch self{
        case .movieURL:
            return "https://api.themoviedb.org/3/movie/popular?language=en-US&page=&api_key=6622998c4ceac172a976a1136b204df4"
        case .detailURL:
            return "https://api.themoviedb.org/3/movie/?language=en-US&api_key=6622998c4ceac172a976a1136b204df4"
        case .imageURL:
            return "https://image.tmdb.org/t/p/w500"
        }
    }
}

   
    

